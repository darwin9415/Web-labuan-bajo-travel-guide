BAJO TRAVEL GUIDE - FILE WEBSITE

Isi paket:
- index.html: halaman website mandiri. Sebagian besar gambar tertanam di dalam file ini.

Cara melihat:
1. Ekstrak ZIP.
2. Buka index.html menggunakan Chrome atau browser lain.
3. Untuk menerbitkan website, unggah index.html ke repository GitHub Pages yang digunakan.

Catatan:
- Koneksi internet diperlukan untuk memuat Google Fonts dan membuka tautan WhatsApp.
- Nomor WhatsApp dan data konten yang sudah ada di file asli tetap dipertahankan.
- Paket ini dibuat dari satu file HTML yang Anda unggah. Aset terpisah yang tidak disertakan dalam unggahan tidak dapat dipulihkan.
